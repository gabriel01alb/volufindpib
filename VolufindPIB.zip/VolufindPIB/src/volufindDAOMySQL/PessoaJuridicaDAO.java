package volufindDAOMySQL;

public interface PessoaJuridicaDAO {
	public void cadastrar(PessoaJuridica usuario);

	public void excluir(PessoaJuridica usuario);

	public PessoaJuridica buscarPorId(Integer id);
	
	public Integer getTotal();

}
