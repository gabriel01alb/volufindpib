package volufindDAOMySQL;

public class MainBanco {

	public static void main(String args[]) {

		/*Observação: a senha do local host não está vazia*/
		
		PessoaFisicaDAO pessoafisicaDAO = new PessoaFisicaDAOMySQL();
		PessoaJuridicaDAO pessoajuridicaDAO = new PessoaJuridicaDAOMySQL();
		UsuarioDAO usuarioDAO = new UsuarioDAOMySQL();

		/* Tabela Pessoa Juridica */
		PessoaJuridica venda = new PessoaJuridica();
		pessoajuridicaDAO.cadastrar(venda);

		/* Tabela Fisica */
		PessoaFisica p1 = new PessoaFisica();
		PessoaFisica p2 = new PessoaFisica();
		PessoaFisica p3 = new PessoaFisica();
		PessoaFisica p4 = new PessoaFisica();

		pessoafisicaDAO.cadastrar(p1);
		pessoafisicaDAO.cadastrar(p2);
		pessoafisicaDAO.cadastrar(p3);
		/* pessoafisicaDAO.cadastrar(p1); *
		pessoafisicaDAO.excluir(p4);

		/* Tabela Usuário */
		
                pessoafisicaDAO.excluir(p4);
                
		Usuario e1 = new Usuario();
		Usuario e2 = new Usuario();
		Usuario e3 = new Usuario();
		
		usuarioDAO.cadastrar(e1);
		usuarioDAO.cadastrar(e2);
		usuarioDAO.cadastrar(e3);
	

	}

}
