package volufindDAOMySQL;


public class PessoaJuridica {

    private Integer id;
    public String nomerep;
    public String email;
    public String endereço;
    public Integer senha;
    public String proposito;
    public String razaosocial;
    public Integer cnpj;
    public String descricao;
    public Integer cep;
    public Integer contato;

    public PessoaJuridica() {

    }

    public PessoaJuridica(Integer pessoaJuridicaid, String nomerep, String email, String endereço, Integer senha, String proposito, String razaosocial, Integer cnpj, String descricao, Integer cep, Integer contato) {
        this.id = pessoaJuridicaid;
        this.nomerep = nomerep;
        this.email = email;
        this.endereço = endereço;
        this.senha = senha;
        this.proposito = proposito;
        this.razaosocial = razaosocial;
        this.cnpj = cnpj;
        this.descricao = descricao;
        this.cep = cep;
        this.contato = contato;
    }

    public Integer getPessoaJuridicaid() {
        return id;
    }

    public void setPessoaJuridicaid(Integer pessoaJuridicaid) {
        this.id = pessoaJuridicaid;
    }

    public String getNomerep() {
        return nomerep;
    }

    public void setNomerep(String nomerep) {
        this.nomerep = nomerep;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEndereço() {
        return endereço;
    }

    public void setEndereço(String endereço) {
        this.endereço = endereço;
    }

    public Integer getSenha() {
        return senha;
    }

    public void setSenha(Integer senha) {
        this.senha = senha;
    }

    public String getProposito() {
        return proposito;
    }

    public void setProposito(String proposito) {
        this.proposito = proposito;
    }

    public String getRazaosocial() {
        return razaosocial;
    }

    public void setRazaosocial(String razaosocial) {
        this.razaosocial = razaosocial;
    }

    public Integer getCnpj() {
        return cnpj;
    }

    public void setCnpj(Integer cnpj) {
        this.cnpj = cnpj;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Integer getCep() {
        return cep;
    }

    public void setCep(Integer cep) {
        this.cep = cep;
    }

    public Integer getContato() {
        return contato;
    }

    public void setContato(Integer contato) {
        this.contato = contato;
    }

    void getId(int aInt) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }


}
