package volufindDAOMySQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PessoaFisicaDAOMySQL implements PessoaFisicaDAO {

	private static final String INSERT_PESSOAFISICA = "INSERT INTO pessoaFisica VALUES (?, ?, ?)";
	private static final String SELECT_PESSOAFISICA = "SELECT * FROM pessoaFisica WHERE pessoaFisicaid = ?";
	private static final String UPDATE_PESSOAFISICA = "UPDATE pessoaFisica SET nome = ?, valor = ? WHERE pessoaFisicaid = ?";
	private static final String DELETE_PESSOAFISICA = "DELETE FROM pessoaFisica WHERE pessoaFisicaid = ?";

	@Override
	public void cadastrar(PessoaFisica pessoaFisica) {
		if (buscarPorId(pessoaFisica.getId()) != null)
			throw new IllegalArgumentException("Pessoa já cadastrada");
		try (Connection connection = Conexao.getConnection();
				PreparedStatement ps = connection.prepareStatement(INSERT_PESSOAFISICA);)

		{
			ps.setInt(1, pessoaFisica.getId());
			ps.execute();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void editar(PessoaFisica pessoaFisica, String novadescricao, Double novovalor) {
		validarProduto(pessoaFisica);

		try (Connection connection = Conexao.getConnection();
				PreparedStatement ps = connection.prepareStatement(UPDATE_PESSOAFISICA);) {
			ps.setString(1, novadescricao);
			ps.setDouble(2, novovalor);
			ps.setInt(3, pessoaFisica.getId());
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void excluir(PessoaFisica pessoaFisica) {
		validarProduto(pessoaFisica);

		try (Connection connection = Conexao.getConnection();
				PreparedStatement ps = connection.prepareStatement(DELETE_PESSOAFISICA);) {
			ps.setInt(1, pessoaFisica.getId());
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public PessoaFisica buscarPorId(Integer id) {
		PessoaFisica pessoaFisica = new PessoaFisica();
		try (Connection connection = Conexao.getConnection();
				PreparedStatement ps = connection.prepareStatement(SELECT_PESSOAFISICA);) {
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				pessoaFisica.setId(rs.getInt("pessoaFisicaid"));
				return pessoaFisica;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	private void validarProduto(PessoaFisica pessoaFisica) {
		if (pessoaFisica.getId() == null)
			throw new IllegalArgumentException("A pessoaFisica deve ser isntanciada primeiro");
	}

}
