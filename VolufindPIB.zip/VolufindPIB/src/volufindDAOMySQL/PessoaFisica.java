package volufindDAOMySQL;

public class PessoaFisica {
	private Integer id;
	private String nome;
        private String email;
        private Integer senha;
        private Integer cep;
        private Integer cpf;
	private Integer contato;
        private String interesse;
        private String datansc;
        
        

	public PessoaFisica() {

	}

    public PessoaFisica(Integer id, String nome, String email, Integer senha, Integer cep, Integer cpf, Integer contato, String interesse, String datansc) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.cep = cep;
        this.cpf = cpf;
        this.contato = contato;
        this.interesse = interesse;
        this.datansc = datansc;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getSenha() {
        return senha;
    }

    public void setSenha(Integer senha) {
        this.senha = senha;
    }

    public Integer getCep() {
        return cep;
    }

    public void setCep(Integer cep) {
        this.cep = cep;
    }

    public Integer getCpf() {
        return cpf;
    }

    public void setCpf(Integer cpf) {
        this.cpf = cpf;
    }

    public Integer getContato() {
        return contato;
    }

    public void setContato(Integer contato) {
        this.contato = contato;
    }

    public String getInteresse() {
        return interesse;
    }

    public void setInteresse(String interesse) {
        this.interesse = interesse;
    }

    public String getDatansc() {
        return datansc;
    }

    public void setDatansc(String datansc) {
        this.datansc = datansc;
    }

	

}