package volufindDAOMySQL;

public interface UsuarioDAO {
	public void cadastrar(Usuario item);

	public void excluir(Usuario item);

	public Usuario buscarPorId(Integer id);

}
