package volufindDAOMySQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioDAOMySQL implements UsuarioDAO {

	private static final String INSERT_USUARIO = "INSERT INTO usuario(usuarioid ,pessoaFisicaid, pessoaJuridicaid, login, senha) VALUES (?, ?, ?, ?, ?, ?)";
	private static final String SELECT_USUARIO = "SELECT * FROM usuario WHERE usuarioid = ?";
	private static final String DELETE_USUARIO = "DELETE FROM usuario WHERE usuarioid = ?";

	@Override
	public void cadastrar(Usuario usuario) {
		if (buscarPorId(usuario.getId()) != null)
			throw new IllegalArgumentException("Usuário já existe");
		try (Connection connection = Conexao.getConnection();
				PreparedStatement ps = connection.prepareStatement(INSERT_USUARIO);) {

			ps.setInt(1, usuario.getId());
			ps.setString(2, usuario.getLogin());
			ps.setInt(4, usuario.getSenha());
			ps.execute();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void excluir(Usuario usuario) {
		validarUsuario(usuario);

		try (Connection connection = Conexao.getConnection();
				PreparedStatement ps = connection.prepareStatement(DELETE_USUARIO);) {
			ps.setInt(1, usuario.getId());
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public Usuario buscarPorId(Integer id) {
		Usuario usuario = new Usuario();
		try (Connection connection = Conexao.getConnection();
				PreparedStatement ps = connection.prepareStatement(SELECT_USUARIO);) {
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				usuario.setId(rs.getInt("usuarioid"));

				return usuario;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	private void validarUsuario(Usuario usuario) {
		if (usuario.getId() == null)
			throw new IllegalArgumentException("O usuário precisa ser instaciado primeiro");
	}
}
