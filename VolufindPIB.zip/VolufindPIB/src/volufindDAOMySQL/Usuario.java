package volufindDAOMySQL;

public class Usuario {
	private Integer id;
	private PessoaFisica produto;
	private PessoaJuridica venda;
        private String login;
	private Integer senha;

	public Usuario() {

	}

    public Usuario(Integer id, PessoaFisica produto, PessoaJuridica venda, String login, Integer senha) {
        this.id = id;
        this.produto = produto;
        this.venda = venda;
        this.login = login;
        this.senha = senha;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public PessoaFisica getProduto() {
        return produto;
    }

    public void setProduto(PessoaFisica produto) {
        this.produto = produto;
    }

    public PessoaJuridica getVenda() {
        return venda;
    }

    public void setVenda(PessoaJuridica venda) {
        this.venda = venda;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public Integer getSenha() {
        return senha;
    }

    public void setSenha(Integer senha) {
        this.senha = senha;
    }
    
    

	
}
