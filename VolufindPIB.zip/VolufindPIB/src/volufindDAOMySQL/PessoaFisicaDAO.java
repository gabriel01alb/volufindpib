package volufindDAOMySQL;

public interface PessoaFisicaDAO {
	public void cadastrar(PessoaFisica produto);

	public void editar(PessoaFisica produto, String novadescricao, Double novovalor);

	public void excluir(PessoaFisica produto);

	public PessoaFisica buscarPorId(Integer id);
}

