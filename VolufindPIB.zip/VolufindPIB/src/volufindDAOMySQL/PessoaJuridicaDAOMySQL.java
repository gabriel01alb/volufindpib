package volufindDAOMySQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PessoaJuridicaDAOMySQL implements PessoaJuridicaDAO {

	private static final String INSERT_PESSOAJURIDICA = "INSERT INTO pessoajuridica(pessoajuridicaid, datacompra) VALUES (?, ?)";
	private static final String SELECT_PESSOAJURIDICA = "SELECT * FROM pessoajuridica WHERE pessoajuridicaid = ?";
	private static final String DELETE_PESSOAJURIDICA = "DELETE FROM pessoajuridica WHERE pessoajuridicaid = ?";
	private static final String COUNT_USUARIOS = "SELECT COUNT(*) FROM usuario";

	@Override
	public void cadastrar(PessoaJuridica pessoajuridica) {
		if (buscarPorId(pessoajuridica.getPessoaJuridicaid()) != null)
			throw new IllegalArgumentException("Cadastro já existe");
		try (Connection connection = Conexao.getConnection();
				PreparedStatement ps = connection.prepareStatement(INSERT_PESSOAJURIDICA);) {

			ps.setInt(1, pessoajuridica.getPessoaJuridicaid());
			ps.setString(2, pessoajuridica.getNomerep());
                        ps.setString(3, pessoajuridica.getEmail());
                        ps.setInt(4, pessoajuridica.getSenha());
                        ps.setString(5, pessoajuridica.getProposito());
                        ps.setString(6, pessoajuridica.getRazaosocial());
                        ps.setString(6, pessoajuridica.getRazaosocial());
			ps.execute();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void excluir(PessoaJuridica pessoajuridica) {
		validarVenda(pessoajuridica);

		try (Connection connection = Conexao.getConnection();
				PreparedStatement ps = connection.prepareStatement(DELETE_PESSOAJURIDICA);) {
			ps.setInt(1, pessoajuridica.getPessoaJuridicaid());
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public PessoaJuridica buscarPorId(Integer id) {
		PessoaJuridica pessoajuridica = new PessoaJuridica();
		try (Connection connection = Conexao.getConnection();
				PreparedStatement ps = connection.prepareStatement(SELECT_PESSOAJURIDICA);) {
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				pessoajuridica.getId(rs.getInt("usuarioid"));

				return pessoajuridica;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	private void validarVenda(PessoaJuridica pessoajuridica) {
		if (pessoajuridica.getPessoaJuridicaid() == null)
			throw new IllegalArgumentException("A pessoa juridica precisa ser aberta instanciada");
	}

	@Override
	public Integer getTotal() {
		try (Connection connection = Conexao.getConnection();
				PreparedStatement ps = connection.prepareStatement(COUNT_USUARIOS);) {
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				return rs.getInt(1);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

}
